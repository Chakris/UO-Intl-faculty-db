﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'uk', {
	title: 'Color Picker Інтерфейс',
	preview: 'Перегляд наживо',
	config: 'Вставте цей рядок у файл config.js',
	predefined: 'Стандартний набір кольорів'
});
